from __future__ import annotations

import asyncio
from typing import Literal

import discord
from discord.ext import commands

from cogs.stats import build_stats_embed
from services import can_manage, container_from_embed, docker_error, docker_service, is_admin, management_embed, owner_from_embed, stats_values, status_name, store


class ManagementView(discord.ui.View):
    """Persistent controls. The panel footer supplies its target owner after restarts."""

    def __init__(self) -> None:
        super().__init__(timeout=None)

    async def _owner_id(self, interaction: discord.Interaction) -> int | None:
        if not interaction.message:
            return None
        return owner_from_embed(interaction.message)

    async def _container_id(self, interaction: discord.Interaction) -> str | None:
        if not interaction.message:
            return None
        return container_from_embed(interaction.message)

    async def _authorized(self, interaction: discord.Interaction, owner_id: int, *, admin_only: bool = False) -> bool:
        allowed = await is_admin(interaction.user, interaction.guild) if admin_only else await can_manage(interaction.user, interaction.guild, owner_id)
        if not allowed:
            await interaction.followup.send("You are not allowed to manage this VPS.", ephemeral=True)
        return allowed

    async def _load(self, owner_id: int, container_id: str | None = None):
        record = (
            await store.get_user_by_container(container_id)
            if container_id
            else await store.get_user(owner_id)
        )
        if record and record["owner_id"] != owner_id:
            record = None
        if not record:
            raise LookupError("This VPS record has been deleted.")
        container = await docker_service.get(record["container_id"])
        await docker_service.reload(container)
        return record, container

    async def _refresh_panel(
        self,
        interaction: discord.Interaction,
        owner_id: int,
        container_id: str | None,
    ) -> None:
        record, container = await self._load(owner_id, container_id)
        live = None
        if status_name(container).lower() == "running":
            live = stats_values(await docker_service.stats(container))
        await interaction.message.edit(embed=management_embed(record, container, live=live), view=self)

    async def perform(self, interaction: discord.Interaction, action: Literal["start", "stop", "restart", "stats", "sshx", "delete"]) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        owner_id = await self._owner_id(interaction)
        if owner_id is None:
            await interaction.followup.send("This panel is malformed; open a new one with `>manage`.", ephemeral=True)
            return
        container_id = await self._container_id(interaction)
        if not await self._authorized(interaction, owner_id, admin_only=action == "delete"):
            return
        try:
            if action == "stats":
                await interaction.followup.send(
                    embed=await build_stats_embed(owner_id, container_id=container_id),
                    ephemeral=True,
                )
                return
            if action == "sshx":
                cog = interaction.client.get_cog("SSHXCog")
                if cog is None:
                    raise RuntimeError("SSHX service is unavailable.")
                await cog.start_for_interaction(interaction, owner_id, container_id)
                return
            record, container = await self._load(owner_id, container_id)
            state = status_name(container).lower()
            if action == "start":
                if state == "running":
                    await interaction.followup.send("⚠️ The container is already running.", ephemeral=True)
                    return
                await docker_service.action(container, "start")
                message = "▶ Container started."
            elif action == "stop":
                if state != "running":
                    await interaction.followup.send("⚠️ The container is already stopped.", ephemeral=True)
                    return
                await docker_service.action(container, "stop")
                message = "⏹ Container stopped."
            elif action == "restart":
                await docker_service.action(container, "restart")
                message = "🔄 Container restarted."
            else:  # delete
                await docker_service.remove(container)
                await store.remove_user(owner_id, record["container_id"])
                deleted = discord.Embed(title="🗑️ VPS Deleted", description=f"`{record['container_name']}` was removed by {interaction.user.mention}.", color=discord.Color.red())
                await interaction.message.edit(embed=deleted, view=None)
                await interaction.followup.send("Container and stored record deleted.", ephemeral=True)
                return
            await asyncio.sleep(0.5)
            await self._refresh_panel(interaction, owner_id, container_id)
            await interaction.followup.send(message, ephemeral=True)
        except LookupError as exc:
            await interaction.followup.send(str(exc), ephemeral=True)
        except Exception as exc:
            await interaction.followup.send(docker_error(exc), ephemeral=True)

    @discord.ui.button(label="Start", emoji="▶", style=discord.ButtonStyle.success, custom_id="kts:vps:start", row=0)
    async def start(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.perform(interaction, "start")

    @discord.ui.button(label="Stop", emoji="⏹", style=discord.ButtonStyle.secondary, custom_id="kts:vps:stop", row=0)
    async def stop(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.perform(interaction, "stop")

    @discord.ui.button(label="Restart", emoji="🔄", style=discord.ButtonStyle.primary, custom_id="kts:vps:restart", row=0)
    async def restart(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.perform(interaction, "restart")

    @discord.ui.button(label="Live Stats", emoji="📊", style=discord.ButtonStyle.primary, custom_id="kts:vps:stats", row=0)
    async def live_stats(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.perform(interaction, "stats")

    @discord.ui.button(label="SSHX", emoji="🔑", style=discord.ButtonStyle.primary, custom_id="kts:vps:sshx", row=1)
    async def sshx(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.perform(interaction, "sshx")

    @discord.ui.button(label="Delete", emoji="🗑", style=discord.ButtonStyle.danger, custom_id="kts:vps:delete", row=1)
    async def delete(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.perform(interaction, "delete")

    @discord.ui.select(
        placeholder="Choose a management action…",
        options=[
            discord.SelectOption(label="Start", value="start", emoji="▶"),
            discord.SelectOption(label="Stop", value="stop", emoji="⏹"),
            discord.SelectOption(label="Restart", value="restart", emoji="🔄"),
            discord.SelectOption(label="Live Stats", value="stats", emoji="📊"),
            discord.SelectOption(label="SSHX", value="sshx", emoji="🔑"),
            discord.SelectOption(label="Delete (admin)", value="delete", emoji="🗑"),
        ],
        custom_id="kts:vps:select",
        row=2,
    )
    async def select_action(self, interaction: discord.Interaction, select: discord.ui.Select) -> None:
        await self.perform(interaction, select.values[0])


class ManageCog(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @commands.command(name="manage")
    @commands.guild_only()
    async def manage(
        self,
        ctx: commands.Context,
        member: discord.Member | None = None,
        vps_number: int = 1,
    ) -> None:
        """Open the persistent control panel for your VPS, or an admin-selected VPS."""
        target = member or ctx.author
        if not await can_manage(ctx.author, ctx.guild, target.id):
            await ctx.send("You can only open your own management panel.")
            return
        record = await store.get_user(target.id, vps_number)
        if not record:
            await ctx.send(f"VPS #{vps_number} is not registered for {target.mention}.")
            return
        try:
            container = await docker_service.get(record["container_id"])
            await docker_service.reload(container)
            live = stats_values(await docker_service.stats(container)) if status_name(container).lower() == "running" else None
            await ctx.send(embed=management_embed(record, container, live=live), view=ManagementView())
        except Exception as exc:
            await ctx.send(docker_error(exc))


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(ManageCog(bot))
