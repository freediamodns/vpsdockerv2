from __future__ import annotations

import discord
from discord.ext import commands

from services import can_manage, docker_error, docker_service, stats_values, status_name, store, uptime


async def build_stats_embed(
    owner_id: int,
    vps_number: int = 1,
    container_id: str | None = None,
) -> discord.Embed:
    record = (
        await store.get_user_by_container(container_id)
        if container_id
        else await store.get_user(owner_id, vps_number)
    )
    if record and record["owner_id"] != owner_id:
        record = None
    if not record:
        name = "This VPS" if container_id else f"VPS #{vps_number}"
        raise LookupError(f"{name} is not registered for this user.")
    container = await docker_service.get(record["container_id"])
    await docker_service.reload(container)
    if status_name(container).lower() != "running":
        raise RuntimeError("The container must be running to retrieve live statistics.")
    values = stats_values(await docker_service.stats(container))
    embed = discord.Embed(title="📊 Live VPS Statistics", color=discord.Color.teal())
    embed.add_field(name="CPU", value=values["cpu"], inline=True)
    embed.add_field(name="RAM Usage", value=values["ram"], inline=True)
    embed.add_field(name="RAM Limit", value=values["limit"], inline=True)
    embed.add_field(name="Network RX", value=values["rx"], inline=True)
    embed.add_field(name="Network TX", value=values["tx"], inline=True)
    embed.add_field(name="Uptime", value=uptime(container), inline=True)
    embed.add_field(name="Status", value=status_name(container), inline=True)
    embed.set_footer(text=f"Container: {record['container_name']} • Refresh using the panel")
    return embed


class StatsCog(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @commands.command(name="stats")
    @commands.guild_only()
    async def stats(
        self,
        ctx: commands.Context,
        member: discord.Member | None = None,
        vps_number: int = 1,
    ) -> None:
        target = member or ctx.author
        if not await can_manage(ctx.author, ctx.guild, target.id):
            await ctx.send("You can only view your own VPS statistics.")
            return
        try:
            await ctx.send(embed=await build_stats_embed(target.id, vps_number))
        except (LookupError, RuntimeError) as exc:
            await ctx.send(str(exc))
        except Exception as exc:
            await ctx.send(docker_error(exc))


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(StatsCog(bot))
