from __future__ import annotations

import discord
from discord.ext import commands

from services import store


def owner_only():
    async def predicate(ctx: commands.Context) -> bool:
        return bool(ctx.guild and ctx.author.id == ctx.guild.owner_id)
    return commands.check(predicate)


class AdminCog(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @commands.group(name="admin", invoke_without_command=True)
    @commands.guild_only()
    async def admin(self, ctx: commands.Context) -> None:
        await ctx.send("Use `>admin add @user` or `>admin remove @user`.")

    @admin.command(name="add")
    @owner_only()
    async def add(self, ctx: commands.Context, member: discord.Member) -> None:
        if member.id == ctx.guild.owner_id:
            await ctx.send("The server owner already has full permissions.")
            return
        await store.add_admin(member.id)
        await ctx.send(f"✅ {member.mention} is now a bot admin.")

    @admin.command(name="remove")
    @owner_only()
    async def remove(self, ctx: commands.Context, member: discord.Member) -> None:
        await store.remove_admin(member.id)
        await ctx.send(f"✅ Removed {member.mention} from bot admins.")

    @commands.command(name="admins")
    @commands.guild_only()
    async def admins(self, ctx: commands.Context) -> None:
        ids = sorted(await store.admins())
        if not ids:
            await ctx.send("There are no configured bot admins. The server owner always has access.")
            return
        embed = discord.Embed(title="🛡️ KTS Bot Admins", color=discord.Color.blurple())
        embed.description = "\n".join(f"• <@{user_id}> (`{user_id}`)" for user_id in ids)
        embed.set_footer(text="Server owner permissions are automatic and are not listed here.")
        await ctx.send(embed=embed)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(AdminCog(bot))
