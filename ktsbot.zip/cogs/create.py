from __future__ import annotations

from datetime import datetime, timezone

import discord
from discord.ext import commands
from docker.errors import APIError

from services import BANNER_FILE, DockerService, docker_error, docker_service, is_admin, store

UTC = timezone.utc


class CreateCog(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @commands.command(name="create")
    @commands.guild_only()
    async def create(self, ctx: commands.Context, member: discord.Member) -> None:
        """Create the managed Ubuntu VPS for a member (owner/admin only)."""
        if not await is_admin(ctx.author, ctx.guild):
            await ctx.send("Only the server owner or a bot admin can create containers.")
            return
        async with store.user_lock(member.id):
            existing = await store.get_users(member.id)
            vps_number = max((record["vps_number"] for record in existing), default=0) + 1
            if existing:
                status = await ctx.send(
                    f"⚠️ {member.mention} already has {len(existing)} VPS. "
                    f"Creating VPS #{vps_number}…"
                )
            else:
                status = await ctx.send(f"Creating an Ubuntu 24.04 VPS for {member.mention}…")
            container = None
            newly_created = False
            try:
                container, newly_created = await docker_service.create(member.id, vps_number)
                await docker_service.reload(container)
                record = {
                    "owner_id": member.id,
                    "owner_name": str(member),
                    "container_name": container.name,
                    "container_id": container.id,
                    "vps_number": vps_number,
                    "image": DockerService.IMAGE,
                    "created_at": datetime.now(UTC).isoformat(),
                }
                await store.put_user(member.id, record)
            except APIError as exc:
                if getattr(exc.response, "status_code", None) == 409:
                    suffix = "" if vps_number == 1 else f"-{vps_number - 1}"
                    await status.edit(
                        content=(
                            f"Docker reports that `user_{member.id}{suffix}` already exists, but it is "
                            "not a managed container that can be safely reused. Stopped containers "
                            "are hidden by `docker ps`; check `docker ps -a` and confirm the bot is "
                            "connected to the same Docker daemon/context."
                        )
                    )
                else:
                    await status.edit(content=docker_error(exc))
                return
            except RuntimeError as exc:
                if container is not None and newly_created:
                    await docker_service.remove(container)
                message = f"VPS provisioning failed: {exc}"
                message += " The incomplete container was removed." if newly_created else " The existing container was left intact."
                await status.edit(content=message)
                return
            except Exception as exc:
                if container is not None and newly_created:
                    try:
                        await docker_service.remove(container)
                    except Exception:
                        pass
                await status.edit(content=docker_error(exc))
                return

            embed = discord.Embed(title="✅ VPS Created", description=f"A managed VPS was created for {member.mention}.", color=discord.Color.green())
            embed.add_field(name="Owner", value=member.mention, inline=True)
            embed.add_field(name="Container Name", value=f"`{container.name}`", inline=True)
            embed.add_field(name="Container ID", value=f"`{container.short_id}`", inline=True)
            embed.add_field(name="VPS Number", value=f"#{vps_number}", inline=True)
            embed.add_field(name="OS", value="Ubuntu 24.04", inline=True)
            embed.add_field(name="Status", value="Running", inline=True)
            embed.add_field(name="RAM Limit", value="32.00 GiB", inline=True)
            embed.add_field(name="CPU Limit", value="6 cores", inline=True)
            embed.add_field(name="Creation Time", value=discord.utils.format_dt(datetime.now(UTC), "F"), inline=True)
            embed.add_field(name="Features", value="Detached • Interactive TTY • curl + nano • Supervisor service manager", inline=False)
            embed.set_footer(text="KTS Host VPS Manager • Use >manage to open controls")
            if BANNER_FILE.exists():
                embed.set_image(url="attachment://banner.png")
                await status.edit(content=None, embed=embed, attachments=[discord.File(BANNER_FILE, filename="banner.png")])
            else:
                await status.edit(content=None, embed=embed)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(CreateCog(bot))
