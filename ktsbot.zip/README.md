# KTS Host VPS Manager

A Discord.py 2.x prefix bot for provisioning and managing per-user Ubuntu 24.04 Docker containers. Prefix: `>`.

## Prerequisites

- Python 3.10 or later (Python 3.11+ recommended)
- A running Docker daemon accessible to the bot process
- A Discord application/bot token
- Discord Developer Portal intents enabled: **Message Content Intent** and **Server Members Intent**

## Setup

1. Create and activate a virtual environment.

   ```powershell
   py -3.11 -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   ```

2. Copy `.env.example` to `.env`, then set `DISCORD_TOKEN`. On Linux, leave `DOCKER_BASE_URL` unset for Docker's default socket. On Windows Docker Desktop, configure it only if your Docker SDK endpoint differs from the default environment.

3. Ensure the operating-system account running the bot can access Docker. On Linux this commonly means adding it to the `docker` group, then signing in again.

4. Run the bot:

   ```powershell
   python bot.py
   ```

## Commands

| Command | Access | Purpose |
| --- | --- | --- |
| `>create @user` | Server owner / bot admin | Provision another 32 GiB, 4-core VPS; warns if the user already has one. |
| `>manage [@user] [vps_number]` | Owner for self; admin for any | Open that VPS's persistent management panel (defaults to VPS #1). |
| `>stats [@user] [vps_number]` | Owner for self; admin for any | Show the selected VPS's current live usage (defaults to VPS #1). |
| `>sshx [@user] [vps_number]` | Owner for self; admin for any | Start SSHX for the selected VPS and DM the private link (defaults to VPS #1). |
| `>admin add @user` | Server owner | Grant bot-admin access. |
| `>admin remove @user` | Server owner | Revoke bot-admin access. |
| `>admins` | Everyone | List configured bot admins. |

## Operational notes

- The server owner always has full permission and is never required in `admins.json`.
- A user may own multiple VPS containers. The first uses `user_<Discord ID>` / `KTS-<Discord ID>`; additional VPSs use `-1`, `-2`, and so on. To select a VPS other than #1, include its number after the optional member, for example `>manage @member 2`. Users managing their own VPS can mention themselves to select a number, e.g. `>stats @self 2`.
- Existing single-VPS records are treated as VPS #1 and are converted to the multi-VPS format when the user data is next updated.
- New containers use a locally built Ubuntu image with `curl`, `nano`, `ca-certificates`, and Supervisor preinstalled. The first creation builds this image and requires the Docker daemon to have network access to Ubuntu package repositories.
- Containers provide a limited `systemctl` compatibility command backed by Supervisor. `status`, `start`, `stop`, `restart`, `reload`, `list-units`, and `daemon-reload` work for programs configured under `/etc/supervisor/conf.d/`; basic SysV init scripts under `/etc/init.d/` are also delegated to `service`. This is not systemd: systemd units, targets, timers, `enable`, and `disable` are not supported. For Supervisor programs, set `autostart=true` or `autostart=false` in their config to control startup.
- Example Supervisor program config (save as `/etc/supervisor/conf.d/myapp.conf`):

  ```ini
  [program:myapp]
  command=/usr/local/bin/myapp --foreground
  autostart=true
  autorestart=true
  ```

  Then run `systemctl daemon-reload` and `systemctl start myapp`. Use `systemctl status myapp` or `systemctl restart myapp` to manage it.
- Containers created before this service-manager image was introduced cannot be upgraded in place; they must be deleted and recreated. Back up any data first.
- Docker API operations are run in worker threads so Discord interactions remain responsive.
- The bot uses JSON files in `data/` and writes them atomically. Back them up before manual edits.
- Management views are persistent across restarts. Do not alter the `Owner ID` in a panel footer.
- SSHX links and log-derived session details are only ever sent by DM. Treat these links as credentials.
- Containers are labelled `kts.host.managed=true`, `kts.host.owner_id=<Discord ID>`, and `kts.host.vps_number=<number>` for operational auditing.

## Security

This bot grants an interactive root shell inside each container through SSHX. Run it only in trusted servers, limit bot-admin membership, keep Docker access restricted, and understand that Docker socket access is effectively host-administrator access.
