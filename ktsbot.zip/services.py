"""Shared storage, Docker, permissions, and presentation helpers."""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import discord
import docker
from docker.errors import APIError, DockerException, ImageNotFound, NotFound

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
USERS_FILE = DATA_DIR / "users.json"
ADMINS_FILE = DATA_DIR / "admins.json"
BANNER_FILE = ROOT / "assets" / "banner.png"
LOG = logging.getLogger("ktsbot")
EMBED_COLOR = discord.Color.from_rgb(88, 101, 242)
# ``datetime.UTC`` exists only in Python 3.11+. Keep compatibility with
# Ubuntu releases that still ship Python 3.10.
UTC = timezone.utc


def utcnow() -> datetime:
    return datetime.now(UTC)


def display_bytes(value: float | int) -> str:
    units = ("B", "KiB", "MiB", "GiB", "TiB")
    number = float(value)
    for unit in units:
        if abs(number) < 1024 or unit == units[-1]:
            return f"{number:.2f} {unit}"
        number /= 1024
    return f"{number:.2f} TiB"


def parse_docker_time(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


class JsonStore:
    """Small atomic JSON store; VPS lists are keyed by Discord user ID strings."""

    def __init__(self) -> None:
        self.lock = asyncio.Lock()
        self._user_locks: dict[int, asyncio.Lock] = {}

    def user_lock(self, user_id: int) -> asyncio.Lock:
        return self._user_locks.setdefault(user_id, asyncio.Lock())

    @staticmethod
    def _normalize_users(payload: Any) -> dict[str, list[dict[str, Any]]]:
        if not isinstance(payload, dict):
            raise RuntimeError("Invalid user data in users.json")
        normalized: dict[str, list[dict[str, Any]]] = {}
        for user_id, value in payload.items():
            if isinstance(value, dict):
                records = [value]
            elif isinstance(value, list) and all(isinstance(item, dict) for item in value):
                records = value
            else:
                raise RuntimeError(f"Invalid VPS records for user {user_id}")
            for number, record in enumerate(records, start=1):
                record.setdefault("vps_number", number)
            normalized[str(user_id)] = records
        return normalized

    @staticmethod
    def _read(path: Path, default: Any) -> Any:
        try:
            with path.open("r", encoding="utf-8") as handle:
                return json.load(handle)
        except FileNotFoundError:
            return default
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"Invalid JSON in {path}") from exc

    @staticmethod
    def _write(path: Path, payload: Any) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, ensure_ascii=False)
        temporary.replace(path)

    async def users(self) -> dict[str, list[dict[str, Any]]]:
        async with self.lock:
            payload = await asyncio.to_thread(self._read, USERS_FILE, {})
            return self._normalize_users(payload)

    async def get_users(self, user_id: int) -> list[dict[str, Any]]:
        return (await self.users()).get(str(user_id), [])

    async def get_user(self, user_id: int, vps_number: int = 1) -> dict[str, Any] | None:
        return next(
            (record for record in await self.get_users(user_id) if record["vps_number"] == vps_number),
            None,
        )

    async def get_user_by_container(self, container_id: str) -> dict[str, Any] | None:
        for records in (await self.users()).values():
            for record in records:
                if record.get("container_id") == container_id:
                    return record
        return None

    async def put_user(self, user_id: int, record: dict[str, Any]) -> None:
        async with self.lock:
            payload = await asyncio.to_thread(self._read, USERS_FILE, {})
            users = self._normalize_users(payload)
            records = users.setdefault(str(user_id), [])
            if any(item.get("container_id") == record.get("container_id") for item in records):
                raise RuntimeError("This VPS is already registered.")
            if any(item["vps_number"] == record["vps_number"] for item in records):
                raise RuntimeError(f"VPS #{record['vps_number']} is already registered.")
            records.append(record)
            await asyncio.to_thread(self._write, USERS_FILE, users)

    async def remove_user(self, user_id: int, container_id: str) -> None:
        async with self.lock:
            payload = await asyncio.to_thread(self._read, USERS_FILE, {})
            users = self._normalize_users(payload)
            records = users.get(str(user_id), [])
            remaining = [record for record in records if record.get("container_id") != container_id]
            if len(remaining) == len(records):
                raise LookupError("This VPS is no longer registered.")
            if remaining:
                users[str(user_id)] = remaining
            else:
                users.pop(str(user_id), None)
            await asyncio.to_thread(self._write, USERS_FILE, users)

    async def admins(self) -> set[int]:
        async with self.lock:
            values = await asyncio.to_thread(self._read, ADMINS_FILE, [])
            return {int(value) for value in values}

    async def add_admin(self, user_id: int) -> None:
        async with self.lock:
            admins = set(await asyncio.to_thread(self._read, ADMINS_FILE, []))
            admins.add(user_id)
            await asyncio.to_thread(self._write, ADMINS_FILE, sorted(admins))

    async def remove_admin(self, user_id: int) -> None:
        async with self.lock:
            admins = set(await asyncio.to_thread(self._read, ADMINS_FILE, []))
            admins.discard(user_id)
            await asyncio.to_thread(self._write, ADMINS_FILE, sorted(admins))


class DockerService:
    IMAGE = "ktsbot-ubuntu:24.04-systemctl-v1"
    MEMORY_LIMIT = 32 * 1024**3
    CPU_NANO = 4_000_000_000  # Docker NanoCPUs: exactly four CPU cores.

    def __init__(self) -> None:
        self._client: docker.DockerClient | None = None
        self._client_lock = asyncio.Lock()
        self._image_lock = asyncio.Lock()
        self._image_ready = False

    async def client(self) -> docker.DockerClient:
        async with self._client_lock:
            if self._client is None:
                base_url = os.getenv("DOCKER_BASE_URL")
                self._client = await asyncio.to_thread(
                    docker.DockerClient, base_url=base_url, timeout=60
                ) if base_url else await asyncio.to_thread(docker.from_env, timeout=60)
                await asyncio.to_thread(self._client.ping)
            return self._client

    async def get(self, name_or_id: str):
        client = await self.client()
        return await asyncio.to_thread(client.containers.get, name_or_id)

    @staticmethod
    def _build_image(client: docker.DockerClient) -> None:
        _, logs = client.images.build(
            path=str(ROOT / "container"),
            dockerfile="Dockerfile",
            tag=DockerService.IMAGE,
            rm=True,
        )
        for event in logs:
            if event.get("error"):
                raise DockerException(event["error"])

    async def ensure_image(self, client: docker.DockerClient) -> None:
        async with self._image_lock:
            if self._image_ready:
                return
            try:
                image = await asyncio.to_thread(client.images.get, self.IMAGE)
            except ImageNotFound:
                image = None
            if image is None or (image.labels or {}).get("kts.host.image_version") != "1":
                await asyncio.to_thread(self._build_image, client)
            self._image_ready = True

    async def reload(self, container: Any) -> None:
        await asyncio.to_thread(container.reload)

    async def create(self, owner_id: int, vps_number: int):
        client = await self.client()
        await self.ensure_image(client)
        suffix = "" if vps_number == 1 else f"-{vps_number - 1}"
        name = f"user_{owner_id}{suffix}"
        try:
            container = await asyncio.to_thread(
                client.containers.run,
                self.IMAGE,
                name=name,
                hostname=f"KTS-{owner_id}{suffix}",
                detach=True,
                tty=True,
                stdin_open=True,
                mem_limit=self.MEMORY_LIMIT,
                nano_cpus=self.CPU_NANO,
                labels={
                    "kts.host.managed": "true",
                    "kts.host.owner_id": str(owner_id),
                    "kts.host.vps_number": str(vps_number),
                },
            )
            return container, True
        except APIError as exc:
            if getattr(exc.response, "status_code", None) != 409:
                raise

            # Docker name conflicts include stopped containers, which are not
            # visible in `docker ps`. Reuse only a container this service owns.
            try:
                existing = await asyncio.to_thread(client.containers.get, name)
            except NotFound:
                raise exc

            labels = existing.labels or {}
            if (
                labels.get("kts.host.managed") != "true"
                or labels.get("kts.host.owner_id") != str(owner_id)
                or labels.get("kts.host.vps_number") != str(vps_number)
            ):
                raise exc

            await asyncio.to_thread(existing.reload)
            if existing.attrs.get("Config", {}).get("Image") != self.IMAGE:
                raise RuntimeError(
                    "This existing container predates the service manager. "
                    "Delete and recreate it to enable systemctl-compatible commands."
                )
            if existing.attrs.get("State", {}).get("Status") != "running":
                await asyncio.to_thread(existing.start)
                await asyncio.to_thread(existing.reload)
            return existing, False

    async def action(self, container: Any, action: str) -> None:
        method = getattr(container, action)
        await asyncio.to_thread(method)

    async def remove(self, container: Any) -> None:
        await asyncio.to_thread(container.remove, force=True)

    async def stats(self, container: Any) -> dict[str, Any]:
        return await asyncio.to_thread(container.stats, stream=False)

    async def exec(self, container: Any, command: str, *, detach: bool = False) -> Any:
        return await asyncio.to_thread(container.exec_run, ["bash", "-lc", command], detach=detach)


store = JsonStore()
docker_service = DockerService()


async def is_admin(member: discord.abc.User, guild: discord.Guild | None) -> bool:
    return bool(guild and member.id == guild.owner_id) or member.id in await store.admins()


async def can_manage(member: discord.abc.User, guild: discord.Guild | None, owner_id: int) -> bool:
    return member.id == owner_id or await is_admin(member, guild)


def owner_from_embed(message: discord.Message) -> int | None:
    footer = message.embeds[0].footer.text if message.embeds and message.embeds[0].footer else ""
    match = re.search(r"Owner ID: (\d+)", footer or "")
    return int(match.group(1)) if match else None


def container_from_embed(message: discord.Message) -> str | None:
    footer = message.embeds[0].footer.text if message.embeds and message.embeds[0].footer else ""
    match = re.search(r"VPS ID: ([a-fA-F0-9]+)", footer or "")
    return match.group(1) if match else None


def status_name(container: Any) -> str:
    return str(container.attrs.get("State", {}).get("Status", "unknown")).capitalize()


def uptime(container: Any) -> str:
    started = parse_docker_time(container.attrs.get("State", {}).get("StartedAt"))
    if not started or status_name(container).lower() != "running":
        return "Not running"
    seconds = max(0, int((utcnow() - started).total_seconds()))
    days, seconds = divmod(seconds, 86400)
    hours, seconds = divmod(seconds, 3600)
    minutes, _ = divmod(seconds, 60)
    return f"{days}d {hours}h {minutes}m"


def stats_values(payload: dict[str, Any]) -> dict[str, str]:
    memory = payload.get("memory_stats", {})
    usage = memory.get("usage", 0) - memory.get("stats", {}).get("cache", 0)
    limit = memory.get("limit", DockerService.MEMORY_LIMIT)
    cpu = payload.get("cpu_stats", {})
    previous = payload.get("precpu_stats", {})
    cpu_delta = cpu.get("cpu_usage", {}).get("total_usage", 0) - previous.get("cpu_usage", {}).get("total_usage", 0)
    system_delta = cpu.get("system_cpu_usage", 0) - previous.get("system_cpu_usage", 0)
    online = cpu.get("online_cpus") or len(cpu.get("cpu_usage", {}).get("percpu_usage", [])) or 1
    cpu_percent = (cpu_delta / system_delta * online * 100) if system_delta > 0 else 0.0
    networks = payload.get("networks", {})
    rx = sum(item.get("rx_bytes", 0) for item in networks.values())
    tx = sum(item.get("tx_bytes", 0) for item in networks.values())
    return {"cpu": f"{cpu_percent:.2f}%", "ram": display_bytes(usage), "limit": display_bytes(limit), "rx": display_bytes(rx), "tx": display_bytes(tx)}


def management_embed(record: dict[str, Any], container: Any, live: dict[str, str] | None = None) -> discord.Embed:
    created = parse_docker_time(record.get("created_at"))
    embed = discord.Embed(title="🛠️ KTS Host VPS Manager", color=EMBED_COLOR, timestamp=utcnow())
    embed.add_field(name="Owner", value=f"{record['owner_name']} (`{record['owner_id']}`)", inline=True)
    embed.add_field(name="Container", value=f"`{record['container_name']}`", inline=True)
    embed.add_field(name="Container ID", value=f"`{record['container_id'][:12]}`", inline=True)
    embed.add_field(name="Status", value=f"**{status_name(container)}**", inline=True)
    embed.add_field(name="OS", value="Ubuntu 24.04", inline=True)
    embed.add_field(name="RAM Usage", value=live["ram"] if live else "Start container for live data", inline=True)
    embed.add_field(name="RAM Limit", value=live["limit"] if live else "32.00 GiB", inline=True)
    embed.add_field(name="CPU Limit", value="4 cores", inline=True)
    embed.add_field(name="Uptime", value=uptime(container), inline=True)
    embed.add_field(name="Creation Date", value=discord.utils.format_dt(created, "F") if created else "Unknown", inline=False)
    embed.set_footer(
        text=(
            f"KTS Host • Owner ID: {record['owner_id']} • VPS #{record.get('vps_number', 1)} "
            f"• VPS ID: {record['container_id']} • Use the controls below"
        )
    )
    return embed


def docker_error(exc: Exception) -> str:
    if isinstance(exc, NotFound):
        return "The Docker container no longer exists."
    if isinstance(exc, ImageNotFound):
        return "The Ubuntu image could not be found or pulled."
    if isinstance(exc, (APIError, DockerException)):
        LOG.exception("Docker operation failed")
        return "Docker could not complete that operation. Check the bot logs and Docker daemon."
    LOG.exception("Unexpected operation failure")
    return "An unexpected error occurred."
